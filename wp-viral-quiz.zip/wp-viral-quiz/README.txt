INTRODUCTION
------------

Create awesome and viral quizzes on your blog, as Buzzfeed does.

FEATURES
--------

* Works with every themes : don’t worry, it works on your site.
* 2 kinds of quizzes : Personality & Trivia Quiz
* Random Quizzes : Let people play with random questions
* Fully Responsive : people can play everywhere !
* Multi-pages quizzes : create multi-pages quizzes !
* Awesome Marketing Tool : capture the email of each players
* Monetization : increase pageviews with the “browser refresh” feature
* Insanely Viral : Force people to share your quiz to see result!
* Analytics : See how many people play your quizzes, and analyze their responses
* Delivered with 2 skins : BuzzFeed Theme and Modern Flat Theme
* Customisable : create your own CSS theme if you want !
* Multilingual : English, French, Spanish, German, Romanian, Portuguese, Japanese, Turkish, Russian, Swedish and more to come.
* Nice Share buttons : people can share your quizzes easily
* Auto-Update : the plugin can be updated from your Wordpress Panel

++ Changelogs here : http://codecanyon.net/item/wordpress-viral-quiz-buzzfeed-quiz-builder/11178623

INSTALLATION
------------

1. Go on your Wordpress Admin
2. Click "Plugins >> Add new"
3. Click "Upload plugin"
4. Select the plugin zipped file and validate
5. Activate the plugin

HOW TO USE
-----------

Look at the /documentation folder to get some help.

SUPPORT
-------

If you need help, feel free to contact us :
@ https://www.ohmyquiz.io/support/


