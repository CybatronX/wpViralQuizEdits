﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'ja', {
	alt: '代替テキスト',
	btnUpload: 'サーバーに送信',
	captioned: 'キャプションを付ける',
	captionPlaceholder: 'キャプション',
	infoTab: '画像情報',
	lockRatio: '比率を固定',
	menu: '画像のプロパティ',
	pathName: 'image',
	pathNameCaption: 'caption',
	resetSize: 'サイズをリセット',
	resizer: 'ドラッグしてリサイズ',
	title: '画像のプロパティ',
	uploadTab: 'アップロード',
	urlMissing: '画像のURLを入力してください。'
} );
